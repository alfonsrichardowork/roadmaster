
import DompurifyContent from '@/components/dompurifyText'
import SpecificationTable from '@/components/spec-table'
import { Button } from '@/components/ui/button'
import { Link as Link18n } from '@/i18n/navigation'
import prismadb from '@/lib/prismadb'
import { Download } from 'lucide-react'
import { getTranslations, setRequestLocale } from 'next-intl/server'
import Image from 'next/image'
import Link from 'next/link'

export interface SpecificationProp {
  parentname: string
  child: ChildSpecificationProp[]
}

export interface ChildSpecificationProp {
  childname: string
  value: string
  slug: string
  notes: string
  unit: string
  subParentName: string
}

const order: Record<string, number> = {
  "Category": 0,
  "Sub Category": 1,
  "Sub Sub Category": 2,
};

export async function generateStaticParams(){
  const products = await prismadb.product.findMany({
    where: {
      isArchived: false
    },
    select: {
      slug: true,
    },
  });
  return products.map((product: { slug: string }) => ({
    productSlug: product.slug
  }));
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ locale: string, productSlug: string }>
}) {
  const { locale, productSlug } = await params;
  const t = await getTranslations({
    locale,
    namespace: 'Single Product Page'
  });
  setRequestLocale(locale);
  const product = await prismadb.product.findFirst({
    where: {
      slug: productSlug
    },
    include: {
      allCat: {
        include: {
          category: true
        }
      },
      multipleDatasheetProduct: {
        select: {
          name: true,
          url: true
        }
      },
      connectorSpecifications: {
        include: {
          dynamicspecification: true,
          dynamicspecificationParent: true,
          dynamicspecificationSubParent: true
        }
      }
    }
  });

  const specsCombined = (product?.connectorSpecifications ?? []).reduce<SpecificationProp[]>(
    (acc, connector) => {
      const parentname = locale === 'en' ? connector.dynamicspecificationParent?.name_eng : connector.dynamicspecificationParent?.name ?? "";
      const subparentname = locale === 'en' ? connector.dynamicspecificationSubParent?.name_eng : connector.dynamicspecificationSubParent?.name ?? "";

      const child: ChildSpecificationProp = {
        childname: locale === 'en' ? connector.dynamicspecification?.name_eng : connector.dynamicspecification?.name ?? "",
        value: locale === 'en' ? connector.value_eng : connector.value ?? "",
        notes: locale === 'en' ? connector.notes_eng : connector.notes ?? "",
        slug: locale === 'en' ? connector.dynamicspecification?.slug_eng : connector.dynamicspecification?.slug ?? "",
        unit: connector.dynamicspecification?.unit ?? "",
        subParentName: subparentname ?? ''
      };

      const existingGroup = acc.find(
        (group) =>
          group.parentname === parentname
      );

      if (existingGroup) {
        existingGroup.child.push(child);
      } else {
        acc.push({ parentname, child: [child] });
      }

      return acc;
    },
    []
  );

  // ✅ Build lookup maps for faster access
  const parentPriorityMap = new Map(
    product?.connectorSpecifications.map((c) => [
      locale === 'en' ? c.dynamicspecificationParent?.name_eng : c.dynamicspecificationParent?.name ?? "",
      c.dynamicspecificationParent?.priority ?? 0,
    ])
  );

  const childPriorityMap = new Map(
    product?.connectorSpecifications.map((c) => [
      locale === 'en' ? c.dynamicspecification?.name_eng : c.dynamicspecification?.name ?? "",
      c.dynamicspecification?.priority ?? 0,
    ])
  );

  // ✅ Sort parent/subparent groups by priority
  specsCombined.sort((a, b) => {
    const aParentPriority = Number(parentPriorityMap.get(a.parentname)) ?? 0;
    const bParentPriority = Number(parentPriorityMap.get(b.parentname)) ?? 0;
    if (aParentPriority !== bParentPriority)
      return aParentPriority - bParentPriority;
    
    return 0;
  });

  // ✅ Sort children inside each group by their own priority
  specsCombined.forEach((group) => {
    group.child.sort((a, b) => {
      const aPriority = Number(childPriorityMap.get(a.childname)) ?? 0;
      const bPriority = Number(childPriorityMap.get(b.childname)) ?? 0;
      return aPriority - bPriority;
    });
  });


  if (!product) {
    return (
      <>
        <main className="pt-32 pb-20 px-4">
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl font-bold text-primary mb-4">{t('not-found-title')}</h1>
            <Button asChild>
              <Link18n href="/category">{t('not-found-button')}</Link18n>
            </Button>
          </div>
        </main>
      </>
    )
  }
  return (
    <>
        {/* Breadcrumb */}
        <div className="pt-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-2 text-sm text-foreground">
              <Link18n href="/" className="hover:text-accent">Home</Link18n>
              <span>/</span>
              <Link18n href="/category" className="hover:text-accent">{t('product-breadcrumb')}</Link18n>
              <span>/</span>
              <span className="text-primary font-semibold">{product.name}</span>
            </div>
          </div>
        </div>

        {/* Product Details Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              {/* Product Image */}
              <div className="fade-in-left flex items-center justify-center">
                <div className="relative w-full">
                  {/* <div className="absolute -inset-4 bg-gradient-to-br from-accent/40 to-accent/10 rounded-3xl blur-2xl opacity-75"></div> */}
                  {/* <div className="relative bg-gradient-to-br from-accent/20 to-accent/5 rounded-2xl p-8 flex items-center justify-center h-full"> */}
                    <Image src={process.env.NEXT_PUBLIC_ROOT_URL + product.cover_img} alt={product.name} width={1000} height={1000} className='max-h-full w-full'/>
                  {/* </div> */}
                </div>
              </div>

              {/* Product Info */}
              <div className="fade-in-right space-y-8 h-full justify-center flex flex-col">
                  <p className="text-sm text-accent font-semibold uppercase tracking-wider mb-2">
                    {product.allCat && product.allCat.length > 0
                      ? product.allCat
                          .sort((a, b) => (order[a.category.type] ?? 99) - (order[b.category.type] ?? 99))
                          .map((cat) => locale === 'en' ? cat.category.name_eng : cat.category.name)
                          .join(" - ")
                      : ""}
                  </p>
                  <h1 className="text-4xl lg:text-5xl font-bold text-primary mb-4">
                    {product.name}
                  </h1>
                    <DompurifyContent text={locale === 'en' ? product.description_eng : product.description || ""} />
                    {product.multipleDatasheetProduct && product.multipleDatasheetProduct.length > 0 &&
                      <div>
                        <h2 className='font-bold text-base mb-1'>Datasheet:</h2>
                        {product.multipleDatasheetProduct.map((value, index) => (
                          value.url !== '' &&
                          <div key={index} className={`${index !== 0 && 'pt-4'}`}>
                            <Link href={value.url} target="_blank" className={`flex items-center hover:text-accent hover:underline`}> 
                            <Download className="h-4 w-fit" strokeWidth={3} width={100} height={100}/>
                            <h3 className="pl-2">
                              {value.name}
                            </h3>
                          </Link>
                          </div>
                        ))}
                    </div>      
                    }
                </div>
            </div>
          </div>
        </section>


        <div className='bg-foreground/5'>
          <div className="md:py-20 py-10 px-4 sm:px-6 lg:px-8 ">
            <div className="max-w-6xl mx-auto">
              {specsCombined && specsCombined.length > 0 &&
                <SpecificationTable spec={specsCombined} />
              }
            </div>
          </div>
        </div>
    </>
  )
}