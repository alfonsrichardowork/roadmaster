"use client"

import * as z from "zod"
import axios, { AxiosResponse } from "axios"
import { useEffect, useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { toast } from "react-hot-toast"
import { allcategory } from "@prisma/client"
import { useParams, useRouter } from "next/navigation"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/app/admin/components/ui/form"
import { Separator } from "@/components/ui/separator"
import { Heading } from "@/app/admin/components/ui/heading"
import { Trash } from "lucide-react"
import Image from "next/image"
import { uploadImage } from "@/app/admin/upload-image"
import { MAX_SIZE } from "@/app/admin/model/model"

const formSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  name_eng: z.string().min(1),
  description_eng: z.string().min(1),
  type: z.string().min(1),
  thumbnail_url: z.string().optional()
});

type SubCategoryFormValues = z.infer<typeof formSchema>

interface SubCategoryFormProps {
  initialData: allcategory | null;
};

export const SubCategoryForm: React.FC<SubCategoryFormProps> = ({
  initialData
}) => {
  const params = useParams();
  const router = useRouter();

  const [coverImgUrl, setCoverImgUrl] = useState<string>();
  const [coverImg, setCoverImg] = useState<File>();

  const [loading, setLoading] = useState(false);

  const title = initialData ? 'Edit Sub Category' : 'Create Sub Category';
  const description = initialData ? 'Edit a Sub Category.' : 'Add a new Sub Category';
  const toastMessage = initialData ? 'Sub Category updated.' : 'Sub Category created.';
  const action = initialData ? 'Save changes' : 'Create';

  const form = useForm<SubCategoryFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: initialData || {
      name: '',
      description: '',
      name_eng: '',
      description_eng: '',
      type: 'Sub Category',
      thumbnail_url: ''
    }
  });
  
  useEffect(() => {
    const fetchData = async () => {
      if (initialData && initialData.thumbnail_url) {
        setCoverImgUrl(initialData.thumbnail_url);
      }
      else{
        setCoverImgUrl('')
      }
    };
    
    fetchData().catch((error) => {
      console.error("Error fetching category: ", error);
    });
  }, [params.superiorId, initialData, initialData?.thumbnail_url]);

  //COVER IMAGE
    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if(!file) return
      if (file.size > MAX_SIZE) {
        alert("File size must be less than 2MB");
        e.target.value = "";
        return;
      }
      setCoverImg(file);
    };
  
    const deleteImage = async () => {
      setCoverImgUrl('')
    }
  
    async function handleCoverImageUpload(file: File): Promise<string> {
      if (file) {
        let updatedCoverImage = coverImgUrl ?? ''
        try {
          const formData = new FormData();
          formData.append('image', file);
    
          const url = await uploadImage(formData, 'others');
          updatedCoverImage = url;
          return updatedCoverImage;
        } catch (error) {
          console.error("Error uploading cover image:", error);
          return '';
        }
      }
      return '';
    }
  
  const onSubmit = async (data: SubCategoryFormValues) => {
    try {
      setLoading(true);
      
      if (coverImg) {
        data.thumbnail_url = await handleCoverImageUpload(coverImg)
      }
      else{
        data.thumbnail_url = coverImgUrl
      }

      let response: AxiosResponse;
      if (initialData) {
        const API=`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}${process.env.NEXT_PUBLIC_ADMIN_UPDATE_SUB_CATEGORY}`;
        //@ts-ignore
        const API_EDITED = API.replace('{brandId}', params.brandId)
        //@ts-ignore
        const API_EDITED2 = API_EDITED.replace('{subCategoryId}', params.subCategoryId)
        response = await axios.patch(API_EDITED2, data);
      } else {
        const API=`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}${process.env.NEXT_PUBLIC_ADMIN_ADD_SUB_CATEGORY}`;
        //@ts-ignore
        const API_EDITED = API.replace('{brandId}', params.brandId)
        response = await axios.post(API_EDITED, data);
      }
      if(response.data === 'duplicate'){
        toast.error("Duplicate Sub Category")
      }
      else if(response.data === 'expired_session'){
        router.push(`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}/${params.brandId}/`);
        router.refresh();
        toast.error("Session expired, please login again");
      }
      else if(response.data === 'invalid_token'){
        router.push(`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}/${params.brandId}/`);
        router.refresh();
        toast.error("API Token Invalid, please login again");
      }
      else if(response.data === 'unauthorized'){
        router.push(`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}/${params.brandId}/`);
        router.refresh();
        toast.error("Unauthorized!");
      }
      else{
        router.push(`${process.env.NEXT_PUBLIC_ADMIN_FOLDER_URL}/${params.brandId}/subcategory`);
        router.refresh();
        toast.success(toastMessage);
      }
    } catch (error: any) {
      toast.error('Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
     <div className="flex items-center justify-between">
        <Heading title={title} description={description} />
      </div>
      <Separator />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 w-full">
          <div className="grid md:grid-cols-2 grid-cols-1 md:gap-8 gap-4 rounded-lg p-4 shadow-lg bg-white/50">
           
            <div className="rounded-lg p-4 bg-white/50">
            <div className="text-center pb-2">
              <div className="text-left font-bold">Cover Image</div>
            </div>
              <div className="flex space-x-4 justify-between items-center">
                  {coverImgUrl && (
                    <Image alt={'Cover Image'} src={coverImgUrl.startsWith('/uploads/') ? `${process.env.NEXT_PUBLIC_ROOT_URL}${coverImgUrl}` : coverImgUrl} width={200} height={200} className="w-52 h-fit" priority/>
                  )}
                  {!coverImgUrl && (
                  <Input
                    id={`file`}
                    type="file"
                    accept="image/*"
                    name="file"
                    onChange={(e) =>
                      e.target.files && handleImageChange(e) // Ensure your file upload function can handle image files
                    }
                    disabled={loading}
                    className="border border-gray-300 p-2 rounded-md"
                  />
                  )}
                  {coverImgUrl && coverImgUrl !== '' && (
                  <Button
                    variant={"destructive"}
                    onClick={() => deleteImage()}
                  >
                    <Trash width={20} height={20}  className="text-background"/>
                  </Button>
                )}
                </div>
          </div>
           
          <div className="flex flex-col w-full justify-center rounded-lg p-4 bg-white/50 gap-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold text-base">Name</FormLabel>
                  <FormControl>
                    <Input disabled={loading} placeholder="Sub Category name" {...field} className="bg-white text-black"/>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold text-base">Description</FormLabel>
                  <FormControl>
                    <Input disabled={loading} placeholder="Sub Category description" {...field} className="bg-white text-black"/>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            </div>

          <div className="flex flex-col w-full justify-center rounded-lg p-4 bg-white/50 gap-4">
            <FormField
              control={form.control}
              name="name_eng"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold text-base">Name (English)</FormLabel>
                  <FormControl>
                    <Input disabled={loading} placeholder="Sub Category name (English)" {...field} className="bg-white text-black"/>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description_eng"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold text-base">Description (English)</FormLabel>
                  <FormControl>
                    <Input disabled={loading} placeholder="Sub Category description (English)" {...field} className="bg-white text-black"/>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            </div>
          </div>
          <Button disabled={loading} className="ml-auto bg-green-500 text-white hover:bg-green-600 transition-colors" type="submit" variant={'secondary'}>
            {action}
          </Button>
        </form>
      </Form>
    </>
  );
};
