import { NextResponse } from "next/server";

import prismadb from "@/lib/prismadb";
import { checkAuth, checkBearerAPI, getSession } from "@/app/admin/actions";
import { revalidatePath } from "next/cache";
import path from 'path';
import fs from 'fs/promises';

const slugify = (str: string): string => str.toLowerCase()
                            .replace(/[^a-z0-9]+/g, '-')
                            .replace(/(^-|-$)+/g, '');

export async function GET(req: Request, props: { params: Promise<{ subCategoryId: string }> }) {
  const params = await props.params;
  try {
    if (!params.subCategoryId) {
      return new NextResponse("All Category id is required", { status: 400 });
    }

    const subCategory = await prismadb.allcategory.findUnique({
      where: {
        id: params.subCategoryId,
        type: "Sub Category"
      }
    });
  
    return NextResponse.json(subCategory);
  } catch (error) {
    console.log('[SUB_CATEGORY_GET]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
};

export async function DELETE(
  req: Request,
  props: { params: Promise<{ subCategoryId: string, brandId: string }> }
) {
  const params = await props.params;
  try {
    const session = await getSession();
    if(!session.isLoggedIn){
      return NextResponse.json("expired_session")
    }

    if(!(await checkBearerAPI(session))){
      session.destroy();
      return NextResponse.json("invalid_token")
    }

    if (!params.subCategoryId) {
      return new NextResponse("Sub Category id is required", { status: 400 });
    }
    
    if(!(await checkAuth(session.isAdmin!, params.brandId, session.userId!))){
      return NextResponse.json("unauthorized")
    }    

    const stillused = await prismadb.allproductcategory.findMany({
      where:{
        categoryId: params.subCategoryId,
      }
    })
    if(stillused.length!=0){
      return NextResponse.json("stillused")
    }

    const subcategoryUrl = await prismadb.allcategory.findFirst({
      where: {
        id: params.subCategoryId
      },
      select:{
        thumbnail_url: true
      }
    })
    //Delete physical files
    if(subcategoryUrl) {
      const subcategoryImgPath = path.join(process.cwd(), subcategoryUrl.thumbnail_url);
      try {
        await fs.unlink(subcategoryImgPath);
      } catch (error) {
        console.warn(`Could not delete file ${subcategoryUrl.thumbnail_url}:`, error);
      }
    }

    await prismadb.allcategory.deleteMany({
      where: {
        id: params.subCategoryId,
        brandId: params.brandId
      }
    });
  
    return NextResponse.json("success");
  } catch (error) {
    console.log('[SUB_CATEGORY_DELETE]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
};


export async function PATCH(
  req: Request,
  props: { params: Promise<{ subCategoryId: string, brandId: string }> }
) {
  const params = await props.params;
  try {
    const session = await getSession();

    if(!session.isLoggedIn || !session){
      return NextResponse.json("expired_session")
    }
    

    if(!(await checkBearerAPI(session))){
      session.destroy();
      return NextResponse.json("invalid_token")
    }

    const body = await req.json();

    const { type, name, description, name_eng, description_eng, thumbnail_url } = body;

    if (!name) {
      return new NextResponse("Name is required", { status: 400 });
    }

    if (!name_eng) {
      return new NextResponse("English Name is required", { status: 400 });
    }

    if (!params.subCategoryId) {
      return new NextResponse("Sub Category id is required", { status: 400 });
    }

    if(!(await checkAuth(session.isAdmin!, params.brandId, session.userId!))){
      return NextResponse.json("unauthorized");
    }  
    
    const initial = await prismadb.allcategory.findFirst({
      where:{
        id: params.subCategoryId,
        brandId: params.brandId
      },
      select:{
        name: true,
        name_eng: true,
        thumbnail_url: true
      }
    })

    if(initial){

      if(initial.thumbnail_url && initial.thumbnail_url !== thumbnail_url) {
        const ImgPath = path.join(process.cwd(), initial.thumbnail_url);
        try {
          await fs.unlink(ImgPath);
        } catch (error) {
          console.warn(`Could not delete file ${initial.thumbnail_url}:`, error);
        }
      }

      if(initial.name ===  name || initial.name_eng === name_eng){

        await prismadb.allcategory.update({
          where: {
            id: params.subCategoryId
          },
          data: {
            type,
            name,
            slug: slugify(name),
            description,
            name_eng,
            slug_eng: slugify(name_eng),
            description_eng,
            thumbnail_url,
            updatedAt: new Date(),
            updatedBy: session.name ?? '',
          }
        });

        await prismadb.allproductcategory.updateMany({
          where: {
            categoryId: params.subCategoryId,
          },
          data:{
            updatedAt: new Date(),
          }
        })
        return NextResponse.json("same")
      }
    }

    const duplicates = await prismadb.allcategory.findFirst({
      where:{
        name,
        name_eng,
        type,
        brandId: params.brandId
      }
    })

    if(duplicates){
      return NextResponse.json("duplicate")
    }

    await prismadb.allcategory.update({
      where: {
        id: params.subCategoryId
      },
      data: {
        type,
        name,
        slug: slugify(name),
        description,
        name_eng,
        slug_eng: slugify(name_eng),
        description_eng,
        thumbnail_url,
        updatedAt: new Date(),
        updatedBy: session.name ?? '',
      }
    });
    await prismadb.allproductcategory.updateMany({
      where: {
        categoryId: params.subCategoryId,
      },
      data:{
        updatedAt: new Date(),
      }
    })
  
    // if( type === "Sub Category" ){
    //   revalidatePath(`/drivers/${slugify(name)}`);
    // }
    // else if( type === "Sub Sub Category" ){ 
    //   const allSub = await prismadb.allproductcategory.findMany({
    //     where:{
    //       type: "Sub Category",
    //     }
    //   })
    //   allSub && allSub.length > 0 && allSub.forEach(sub => {
    //     revalidatePath(`/drivers/${sub.slug}/${slugify(name)}`);
    //   });
    // }

    return NextResponse.json("success");
  } catch (error) {
    console.log('[SUB_CATEGORY_PATCH]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
};
